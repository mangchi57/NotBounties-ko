
*=* Custom Posters *=*
You can use any 128x128 pixel png image or edit the template: poster template.png
The head will generate in the center, and it is 64x64 pixels
Below the head will be the name of the player and the reward if bounty-reward is enabled
When you have your png image, delete "bounty poster.png" and upload your file in its place.
Make sure your new file is also called "bounty poster.png"
dead bounty.png will overlay the head when the player doesn't have a bounty. This image is 72x72
Changes will take effect after a server restart

*=* Custom Font *=*
To use your own font, add a true text file called playerfont.ttf to the posters folder
The WANTED text in the poster image is Simsun-ExtB
playerfont.ttf is used to generate the player name and reward text
The text is black

*=* Other Features *=*
You can configure the posters more in the config.yml file.
The posters file will be cleaned regularly if save-templates is disabled in the config

